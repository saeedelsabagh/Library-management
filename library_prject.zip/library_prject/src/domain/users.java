package domain;

import java.sql.*;
import java.util.ArrayList;
import static database.user_database.connect;

public class users {

    private String user, pass;

    public users(String user, String pass) {
        this.user = user;
        this.pass = pass;
    }

    public String getUser() {
        return user;
    }

    public String getPass() {
        return pass;
    }

    public static ArrayList<users> get_user() {
        ArrayList<users> mylist1 = new ArrayList();
        String sql = "select * from user";
        //for (int i = 0; i < mylist1.size(); i++) {
        try (Connection con = connect(); PreparedStatement p = con.prepareStatement(sql);) {
            ResultSet r = p.executeQuery();
            
            while (r.next()) {
                mylist1.add(new users(r.getString("username"), r.getString("password")));
            }
            r.close();
        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
        //}
        return mylist1;
    }
}
