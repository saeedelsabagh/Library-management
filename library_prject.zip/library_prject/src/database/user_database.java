package database;

import domain.users;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
//import javax.swing.JOptionPane;

public class user_database {

    public static Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/forlibrary";
        
        return DriverManager.getConnection(url, "root", "asd12345");

    }

    
//    public void insert_touser(){
//        String sql="insert into users values(s,1)";
//        try{
//            
//        }catch(SQLException ee){
//            JOptionPane.showMessageDialog(null, ee);
//        }
//    }
    public static int check_login(String user, String pass) {
        ArrayList<users> mylist1 = users.get_user();
        int q = 0;
        for (int x = 0; x < mylist1.size(); x++) {
            if (mylist1.get(x).getUser().equals(user)) {
                if (mylist1.get(x).getPass().equals(pass)) {
                    q = 2;
                    break;
                } else {
                    q = 3;//pass!
                    break;
                }
            }

        }
        return q;
    }
}
