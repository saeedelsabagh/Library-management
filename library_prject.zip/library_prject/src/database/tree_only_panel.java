package database;

import java.awt.BorderLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;

public class tree_only_panel extends JPanel {

    public tree_only_panel(
            JTable table,
            input_tree_database db
    ) {

        db.tree.addTreeSelectionListener(e -> {

            DefaultMutableTreeNode node
                    = (DefaultMutableTreeNode) db.tree.getLastSelectedPathComponent();

            if (node == null) {
                return;
            }

            if (node.isLeaf()) {

                String text = node.toString();

                String[] row = text.split("-");

                String subject
                        = node.getParent().toString();

                String stage
                        = ((DefaultMutableTreeNode) node.getParent().getParent())
                                .toString();

                DefaultTableModel model
                        = (DefaultTableModel) table.getModel();

                String price
                        = text.split("\\)")[1]
                                .replace("LE", "")//دا ع يجيب السعر من الشجره ويحطها ف الدول
                                .trim();
                // منع التكرار
                for (int i = 0;
                        i < table.getRowCount();
                        i++) {

                    if (table.getValueAt(i, 0)
                            .toString()
                            .equals(row[0])) {

                        JOptionPane.showMessageDialog(
                                null,
                                "الكتاب موجود"
                        );

                        return;
                    }
                }

                model.addRow(new Object[]{
                    row[0],
                    stage,
                    subject,
                    row[1].split("\\(")[0],
                    1,
                    price
                });
            }
        });

        JScrollPane treeScroll
                = new JScrollPane(db.tree);

        setLayout(new BorderLayout());

        add(treeScroll, BorderLayout.CENTER);
    }
}
