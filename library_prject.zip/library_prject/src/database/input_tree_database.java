package database;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class input_tree_database extends JPanel implements ActionListener {

    JTabbedPane b1;
    JTree tree;
    JLabel stage, subject, book_name, quantity, price;
    JTextField stage_, subject_, book_name_, quantity_, price_;
    JButton send, delete, update;

    public input_tree_database() {

        tree = new JTree(getinfo_fortree());
        tree.setFocusable(false);
//        tree2 = new JTree(getinfo_fortree());
//        tree3 = new JTree(getinfo_fortree());
        JScrollPane sc = new JScrollPane(tree);
//        JScrollPane sc2 = new JScrollPane(tree2);
//        JScrollPane sc3 = new JScrollPane(tree3);
        b1 = new JTabbedPane();
//        in = new input(this);//?
//        b1.addTab("input", in);
        b1.addTab("الكتب", sc);
//        b1.addTab("اعدادي", sc2);
//        b1.addTab("ثانوي", sc3);
        // add(b1);

        stage = new JLabel("stage");
        subject = new JLabel("subject");
        book_name = new JLabel("book_name");
        quantity = new JLabel("quantity");
        price = new JLabel("price");

        stage.setBounds(500, 50, 100, 25);
        subject.setBounds(500, 90, 100, 25);
        book_name.setBounds(500, 130, 100, 25);
        quantity.setBounds(500, 170, 100, 25);
        price.setBounds(500, 210, 100, 25);

//        add(stage);
//        add(subject);
//        add(book_name);
//        add(quantity);
        stage_ = new JTextField();
        subject_ = new JTextField();
        book_name_ = new JTextField();
        quantity_ = new JTextField();
        price_ = new JTextField();

        stage_.setBounds(600, 50, 150, 25);
        subject_.setBounds(600, 90, 150, 25);
        book_name_.setBounds(600, 130, 150, 25);
        quantity_.setBounds(600, 170, 150, 25);
        price_.setBounds(600, 210, 150, 25);

        send = new JButton("add");
        send.setBounds(550, 260, 100, 32);
        send.addActionListener(this);
        delete = new JButton("delete");
        delete.setBounds(680, 260, 100, 32);
        delete.addActionListener(this);
        update = new JButton("update");
        update.setBounds(610, 300, 100, 32);
        update.addActionListener(this);

        JPanel form = new JPanel(null);
        form.setPreferredSize(new java.awt.Dimension(800, 500)); // 🔥 مهم
        form.add(stage);
        form.add(subject);
        form.add(book_name);
        form.add(quantity);
        form.add(price);

        form.add(stage_);
        form.add(subject_);
        form.add(book_name_);
        form.add(quantity_);
        form.add(price_);

        form.add(send);
        form.add(delete);
        form.add(update);
//        this.setLayout(null);
        setLayout(new java.awt.BorderLayout());
        setLayout(new BorderLayout());
        add(b1, BorderLayout.WEST); // الشجرة
        add(form, BorderLayout.EAST); // الفورم تحت
        b1.setPreferredSize(new Dimension(450, 800)); // 👈 عرض الشجرة
//        setTitle("Database Tree");
//        setSize(800, 800);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setLocationRelativeTo(null); // في النص
        setVisible(true);
    }

    public Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/forlibrary";
        return DriverManager.getConnection(url, "root", "asd12345");
    }

    public void updateQuantity(String nodeText, int newQty) {

        try {
            int id = Integer.parseInt(nodeText.split("-")[0]);

            String sql = "UPDATE books SET quantity = ? WHERE id = ?";

            try (Connection con = connect(); PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, newQty);
                ps.setInt(2, id);
                ps.executeUpdate();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error updating");
        }
    }

    public void deleteFromDatabase(String nodeText) {
        try {
            // مثال: "5-Gem (3)"
            int id = Integer.parseInt(nodeText.split("-")[0]);

            String sql = "DELETE FROM books WHERE id = ?";

            try (Connection con = connect(); PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insert_for_input(String stage, String subject, String book, int quantity, int price) {// for tab add   
        String sql = "INSERT INTO books(stage, subject, book_name, quantity,price)\n"
                + "VALUES (?,?,?,?,?)";
        try (java.sql.Connection con = connect(); PreparedStatement p1 = con.prepareStatement(sql)) {

            p1.setString(1, stage);
            p1.setString(2, subject);
            p1.setString(3, book);
            p1.setInt(4, quantity);
            p1.setInt(5, price);

            p1.executeUpdate();

            System.out.println("Inserted successfully ✅");

        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
    }

    public DefaultMutableTreeNode getinfo_fortree() {

        DefaultMutableTreeNode root = new DefaultMutableTreeNode("الكتب");

        String sql = "SELECT * FROM books";

        Map<String, DefaultMutableTreeNode> stageMap = new HashMap<>();
        Map<String, DefaultMutableTreeNode> subjectMap = new HashMap<>();

        try (Connection con = connect(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String stage = rs.getString("stage").trim();
                String subject = rs.getString("subject").trim();
                String book = rs.getString("book_name");
                int qty = rs.getInt("quantity");
                int price = rs.getInt("price");

                // 🟡 stage
                DefaultMutableTreeNode stageNode = stageMap.get(stage);
                if (stageNode == null) {
                    stageNode = new DefaultMutableTreeNode(stage);
                    stageMap.put(stage, stageNode);
                    root.add(stageNode);
                }

                // 🔵 subject
                String key = stage + "-" + subject;
                DefaultMutableTreeNode subjectNode = subjectMap.get(key);
                if (subjectNode == null) {
                    subjectNode = new DefaultMutableTreeNode(subject);
                    subjectMap.put(key, subjectNode);
                    stageNode.add(subjectNode);
                }

                // 🔴 book
                DefaultMutableTreeNode bookNode
                        = new DefaultMutableTreeNode((id + "-" + book + " (" + qty + ")   "+price+"LE"));
                subjectNode.add(bookNode);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return root;
    }

    public void refreshTree() {
        tree.setModel(new DefaultTreeModel(getinfo_fortree()));
    }

    public void deleteSelectedNode() {

        DefaultMutableTreeNode node
                = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();

        if (node == null) {
            JOptionPane.showMessageDialog(null, "اختار كتاب");
            return;
        }

        String text = node.toString();
        // 🔥 الشرط المهم
        if (!node.isLeaf()) {
            JOptionPane.showMessageDialog(null, "مينفعش تمسح غير الكتاب فقط");
            return;
        }
        // حذف من الشجرة
        ((DefaultTreeModel) tree.getModel()).removeNodeFromParent(node);

        deleteFromDatabase(text);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == send) {

            String st = stage_.getText();
            String sub = subject_.getText();
            String book = book_name_.getText();
            int qty = 0;
            try {
                qty = Integer.parseInt(quantity_.getText());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "اكتب رقم");
                return;
            }
            int price=Integer.parseInt(price_.getText());
            
            insert_for_input(st, sub, book, qty, price);
            refreshTree();

            stage_.setText("");
            subject_.setText("");
            book_name_.setText("");
            quantity_.setText("");
            price_.setText("");
        }
        if (e.getSource() == delete) {
            deleteSelectedNode();
        }
        if (e.getSource() == update) {

            if (tree.getSelectionPath() == null) {
                JOptionPane.showMessageDialog(null, "اختار كتاب الاول");
                return;
            }

            DefaultMutableTreeNode node
                    = (DefaultMutableTreeNode) tree.getSelectionPath().getLastPathComponent();
            if (node == null || !node.isLeaf()) {
                JOptionPane.showMessageDialog(null, "اختار كتاب الاول");
                return;
            }

            String text = node.toString();

            int qty;
            try {
                qty = Integer.parseInt(quantity_.getText());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter valid number");
                return;
            }

            updateQuantity(text, qty);

            refreshTree(); // 🔥 تحديث الشجرة
        }
    }
}
