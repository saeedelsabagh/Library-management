package library_prject;

import database.input_tree_database;
import database.user_database;

public class Library_prject {

    public static void main(String[] args) {
        //new input_tree_database();
        input_tree_database db = new input_tree_database();
        //new tree_form_jui(db);
        new thefirst(db);
        //new login();
        // new input();
        // new user_database();
    }

}