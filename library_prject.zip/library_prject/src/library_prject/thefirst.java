package library_prject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import database.input_tree_database;
import database.tree_only_panel;
import static database.user_database.connect;
import domain.input_tree;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class thefirst extends JFrame implements ActionListener {

    ArrayList<input_tree> mylist = new ArrayList();

    String header[] = {
        "id", "stage", "subject", "book_name", "quantity", "price"
    };

    JTable t;
    JTabbedPane tabs;
    JScrollPane sc;
    input_tree_database db;
    JButton b1, save;

    int lastQuantity[] = new int[100];
    boolean saved = false;

    public thefirst(input_tree_database db) {

        this.db = db;

//        try {
//
//            javax.swing.UIManager.setLookAndFeel(
//                    javax.swing.UIManager.getSystemLookAndFeelClassName()
//            );
//
//        } catch (Exception e) {
//
//            e.printStackTrace();
//        }
        setTitle("Library Project");
        setSize(860, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        tabs = new JTabbedPane();

        login l = new login(tabs);
        tabs.addTab("Login", l);

        DefaultTableModel model
                = new DefaultTableModel(header, 0);

        t = new JTable(model);

        sc = new JScrollPane(t);
        sc.setPreferredSize(new java.awt.Dimension(500, 250));

        JSplitPane split = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                new tree_only_panel(t, db),
                sc
        );
        split.setDividerLocation(250);

        JPanel mainPanel
                = new JPanel(new BorderLayout());

        JPanel center = new JPanel(null);

        split.setBounds(0, 0, 850, 330);

        center.add(split);

        mainPanel.add(center, BorderLayout.CENTER);
        b1 = new JButton("print");
        b1.addActionListener(this);
        b1.setBounds(350, 350, 150, 30);

        save = new JButton("save");
        save.addActionListener(this);
        save.setBounds(600, 350, 150, 30);
        add(save);

        center.add(b1);
        center.add(save);
        tabs.addTab("Main", mainPanel);
        tabs.setSelectedIndex(1);

        add(tabs);
        setSize(890, 500);
        setVisible(true);
    }

    public ArrayList<input_tree> get_treefromdata() {

        String sql = "select * from books";

        try (
                Connection con = connect(); PreparedStatement p = con.prepareStatement(sql)) {

            ResultSet rs = p.executeQuery();

            while (rs.next()) {

                mylist.add(new input_tree(
                        rs.getInt("id"),
                        rs.getString("stage"),
                        rs.getString("subject"),
                        rs.getString("book_name"),
                        rs.getInt("quantity"),
                        rs.getInt("price")
                ));
            }

            db.refreshTree();

            rs.close();

        } catch (SQLException ee) {

            JOptionPane.showMessageDialog(null, ee.getMessage());
        }

        return mylist;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == b1) {

            MessageFormat h
                    = new MessageFormat("Library Books");

            MessageFormat f
                    = new MessageFormat("Page {0}");

            try {
                if (!saved) {

                    JOptionPane.showMessageDialog(
                            null,
                            "اضغط save الاول"
                    );

                    return;
                }
                t.print(JTable.PrintMode.FIT_WIDTH, h, f);

            } catch (Exception ee) {

                System.out.println(ee.getMessage());
            }
        }
        if (e.getSource() == save) {

            if (t.isEditing()) {

                t.getCellEditor().stopCellEditing();
            }

            for (int i = 0; i < t.getRowCount(); i++) {
                String sql
                        = "update books set quantity =quantity - ? where id=?";

                try (
                        Connection con = connect(); PreparedStatement p
                        = con.prepareStatement(sql)) {

                    int newQuantity
                            = Integer.parseInt(
                                    t.getValueAt(i, 4).toString()
                            );

                    int difference
                            = newQuantity - lastQuantity[i];

                    p.setInt(1, difference);

                    lastQuantity[i] = newQuantity;

                    p.setInt(
                            2,
                            Integer.parseInt(
                                    t.getValueAt(i, 0).toString()
                            )
                    );

                    p.executeUpdate();

                } catch (Exception ee) {

                    System.out.println(ee.getMessage());
                }
            }
          
            db.refreshTree();
            saved = true;
        }
    }
}
