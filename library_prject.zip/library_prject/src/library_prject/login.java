package library_prject;

import database.input_tree_database;
import database.user_database;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class login extends JPanel implements ActionListener {

    ImageIcon icon
            = new ImageIcon(
                    getClass().getResource("p.jpg")
            );

    JLabel user, pass, img;
    JTextField user_, pass_;
    JButton login;
    JTabbedPane tabs;

    public login(JTabbedPane tabs) {
        this.tabs = tabs;
        setLayout(null);

        img = new JLabel(icon);
        img.setBounds(0, 0, 900, 500);
        add(img);
        setComponentZOrder(img, getComponentCount() - 1);
        
        
        user = new JLabel("user");
        pass = new JLabel("pass");
        user.setForeground(Color.white);
        pass.setForeground(Color.white);
        user.setBounds(500, 240, 100, 25);
        pass.setBounds(500, 280, 100, 25);
        add(user);
        add(pass);
        setComponentZOrder(img, getComponentCount() - 1);
        
        user_ = new JTextField();
        pass_ = new JTextField();
        user_.setBounds(600, 240, 150, 25);
        pass_.setBounds(600, 280, 150, 25);
        add(user_);
        add(pass_);
        setComponentZOrder(img, getComponentCount() - 1);
        
        login = new JButton("login");
        add(login);
        login.setBounds(570, 330, 100, 30);
        login.addActionListener(this);
        setComponentZOrder(img, getComponentCount() - 1);
        
        setSize(1100, 900);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == login) {
            int n = user_database.check_login(user_.getText(), pass_.getText());
            System.out.println(n);
            switch (n) {
                case 2:

                    input_tree_database panel = new input_tree_database();
                    tabs.setComponentAt(0, panel);      // يستبدل login
                    tabs.setTitleAt(0, "input");    // يغير الاسم

                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "password wrong");
            }
        }
    }
}
