package library_prject;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class img extends JPanel {

    private ImageIcon i;

    public img() {

        setLayout(null);

        i = new ImageIcon(
                getClass().getResource("p3.png")
        );
    }

    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        i.paintIcon(this, g, 0, 0);
    }
}